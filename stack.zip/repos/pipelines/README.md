# Pipeline repository

The *script* folder contains all the scripts for the pipelines to run. These scripts are common for every pipeline.